import fetch from 'node-fetch';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const { ALI_APP_KEY, ALI_APP_SECRET, ALI_TRACKING_ID } = process.env;
const ALI_API_URL = 'https://api-sg.aliexpress.com/sync';

function createSignature(params) {
  const sorted = Array.from(params.keys()).sort();
  let str = ALI_APP_SECRET || '';
  for (const k of sorted) str += k + params.get(k);
  str += ALI_APP_SECRET || '';
  return crypto.createHash('md5').update(str).digest('hex').toUpperCase();
}

async function callAli(method, extra = {}) {
  const params = new URLSearchParams({
    method,
    app_key: ALI_APP_KEY,
    tracking_id: ALI_TRACKING_ID,
    sign_method: 'md5',
    timestamp: new Date().toISOString(),
    format: 'json',
    ...extra
  });
  const sign = createSignature(params);
  params.append('sign', sign);

  const res = await fetch(ALI_API_URL, { method: 'POST', body: params });
  const data = await res.json();
  console.log(JSON.stringify(data, null, 2));
}

(async () => {
  console.log("🔗 Testing AliExpress API...");
  await callAli('aliexpress.affiliate.product.query', { keywords: 'electronics', page_size: 3 });
})();
